import numpy as np


class MessageParser:

    def parse_system_event(self, buffer):
        # for message type 'S'
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        event = buffer[10:11].decode('ascii')
        #     print([lc_tn[0], lc_tn[1], timestamp, event])
        return [timestamp, event]

    def parse_add_order(self, buffer):
        # for message type 'A'
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        buy_sell_ind = buffer[18:19].decode('ascii')
        # num_shares = np.frombuffer(buffer[19:23], dtype='>u4')
        num_shares = int.from_bytes(buffer[19:23], byteorder='big', signed=False)
        stock = buffer[23:31].decode('utf-8').strip()
        # price = np.frombuffer(buffer[31:35], dtype='>u4')
        price = int.from_bytes(buffer[31:35], byteorder='big', signed=False)
        return [timestamp, order_reference_num, buy_sell_ind, num_shares, stock,
                price / 10000]

    def parse_order_executed(self, buffer):
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        num_shares = int.from_bytes(buffer[18:22], byteorder='big', signed=False)
        # order_reference_num = np.frombuffer(buffer[10:18], dtype='>u8')
        # num_shares = np.frombuffer(buffer[18:22], dtype='>u4')
        return [timestamp, order_reference_num, num_shares]

    def parse_order_executed_with_price(self, buffer):
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        # order_reference_num = np.frombuffer(buffer[10:18], dtype='>u8')
        order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        # num_shares = np.frombuffer(buffer[18:22], dtype='>u4')
        num_shares = int.from_bytes(buffer[18:22], byteorder='big', signed=False)
        printable = buffer[22:23].decode('ascii')
        # price = np.frombuffer(buffer[31:35], dtype='>u4')
        price = int.from_bytes(buffer[31:35], byteorder='big', signed=False)
        return [timestamp, order_reference_num, num_shares, price / 10000, printable]

    def parse_order_cancel(self, buffer):
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        num_shares = int.from_bytes(buffer[18:22], byteorder='big', signed=False)
        return [timestamp, order_reference_num, num_shares]

    def parse_order_delete(self, buffer):
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        return [timestamp, order_reference_num]

    def parse_order_replace(self, buffer):
        timestamp = int.from_bytes(buffer[4:10], byteorder='big', signed=False)
        orig_order_reference_num = int.from_bytes(buffer[10:18], byteorder='big', signed=False)
        # new_order_reference_num = np.frombuffer(buffer[18:26], dtype='>u8')
        new_order_reference_num = int.from_bytes(buffer[18:26], byteorder='big', signed=False)
        # num_shares = np.frombuffer(buffer[26:30], dtype='>u4')
        num_shares = int.from_bytes(buffer[26:30], byteorder='big', signed=False)
        # price = np.frombuffer(buffer[30:34], dtype='>u4')
        price = int.from_bytes(buffer[30:34], byteorder='big', signed=False)
        return [timestamp, orig_order_reference_num, new_order_reference_num, num_shares, price / 10000]
