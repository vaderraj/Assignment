
class Order:

    def __init__(self, stock, price, volume):
        self.stock = stock
        self.price = price
        self.volume = volume

