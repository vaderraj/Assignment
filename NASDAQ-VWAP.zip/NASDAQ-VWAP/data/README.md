# nasdaq-itch5.0-parser
## To parse the bytes in Nasdaq itch 5.0 binary file to get stock-related data

## Libraries Used:
1. Numpy to convert the bytes to data according to the type specified in the documentation (https://www.nasdaqtrader.com/content/technicalsupport/specifications/dataproducts/NQTVITCHspecification.pdf)
2. Pandas to save to Excel file


## How to run:
1. If you have virtualenv in your system, you can use it to create virtual environment for running the app.
```commandline
pip install virtualenv

cd <Path to stock_vwap project>
python -m venv env  (Run this in project dir to create env folder)

Activate:
env/Scripts/activate (Windows)
source env/bin/activate (Mac)

Install libraries:
pip install -r requirements.txt
```
2. ### Download the binary file/zip file in the "data" directory in the project
3. Run following command in the project location or 
### run VWAPApp.py and give filename as arg
```commandline
python VWAPApp.py <filename> (use python in this command as saved in your environment, it can be python3/python3.8) (Give filename as argument)
```
4. It will take some time to process.
5. It will create an Excel file with similar name for better visualization

## Data
Download raw ITCH 5.0 data from the following link:
https://emi.nasdaq.com/ITCH/Nasdaq%20ITCH/01302019.NASDAQ_ITCH50.gz
## Specification
The format is defined by the following document:
https://www.nasdaqtrader.com/content/technicalsupport/specifications/dataproducts/NQ
TVITCHspecification.pdf
