import gzip
import os
import shutil
import pandas as pd


class FileUtils:

    def __init__(self):
        self.name = 'default'

    def unzip_binary_file(self, zipped_filename):
        filename_arr = zipped_filename.split('.')
        file_format = filename_arr[-1]
        stem = '.'.join(filename_arr[:-1])
        self.name = stem
        zipped_filepath = os.path.join('data/', zipped_filename)
        unzipped_filepath = os.path.join('data/', stem + '.bin')
        if not os.path.isfile(unzipped_filepath):
            with gzip.open(str(zipped_filepath), 'rb') as f_in:
                with open(unzipped_filepath, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        return unzipped_filepath

    def write_results_to_excel(self, output_data):
        if output_data is not None:
            df = pd.DataFrame.from_dict({(stock, time): output_data[stock]['hourly_data'][time]
                                         for stock in output_data.keys()
                                         for time in output_data[stock]['hourly_data']},
                                        orient='index', columns=['Stock Price'])
            col_list = ['Stock Name', 'Time of Trade']

            df.index = pd.MultiIndex.from_tuples(df.index, names=col_list)
            df.to_excel(os.path.join('data/', self.name + '.xlsx'), sheet_name='hourly_data')