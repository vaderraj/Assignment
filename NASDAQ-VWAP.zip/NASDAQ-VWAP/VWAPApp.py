import os
import sys
import time
import pandas as pd

from parser.MessageParser import MessageParser
from service.VWAPCalcService import VWAPCalcService
from utils.FileUtils import FileUtils


def calculate_vwap_from_bin(filename):
    file_utils = FileUtils()
    parser = MessageParser()
    calc_service = VWAPCalcService(parser)

    data_filename = os.path.join('data/' + filename)
    print(filename)
    # Use a breakpoint in the code line below to debug your script.
    if os.path.isfile(data_filename):
        unzipped_filepath = file_utils.unzip_binary_file(filename)
        start = time.time_ns()
        stock_data = calc_service.read_process_bin(unzipped_filepath)
        print("Total time ", pd.to_timedelta(time.time_ns() - start))
        print("Exporting results to excel in data folder")
        file_utils.write_results_to_excel(stock_data)

    else:
        print("File does not exists. Please add the file in data folder and try again")


if __name__ == '__main__':
    filename = sys.argv[1]
    calculate_vwap_from_bin(filename)


