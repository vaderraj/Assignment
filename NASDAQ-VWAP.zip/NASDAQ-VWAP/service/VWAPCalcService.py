import mmap

from models.Order import Order


class VWAPCalcService:

    def __init__(self, parser):
        self.order_book = {}
        self.stock_data = {}
        self.start_time = None
        self.close_time = None
        self.checkpoint = None
        self.parser = parser

    def read_process_bin(self, filepath):
        for content in self.generate_message_bytes(filepath):
            cat, buffer = content[:1].decode('ascii'), content[1:]

            if cat == 'S':
                res = self.parser.parse_system_event(buffer[:11])
                if res[-1] == 'Q':
                    self.start_time = res[-2] // 1000000000
                    self.checkpoint = self.start_time + 60 * 60
                    print('Start of Market hours at ', self.get_time(res[-2]))  # 9:30:0
                    #                 00:00:59.173116(mmap) 00:00:58.993178
                    print('Please wait until processing is completed at end of market hours')

                elif res[-1] == 'M':
                    self.add_hourly_stock_data(res[-2], True)
                    print('End of Market hours at ', self.get_time(res[-2]))  # 16:0:0 # stop here
                    return self.stock_data

            elif cat in 'AF':
                if self.start_time is not None:

                    res = self.parser.parse_add_order(buffer[:35])
                    if res[0] >= self.start_time * 1e9:
                        self.save_and_process_add_order(res[1], res[4], res[5], res[3])

            # Trade Messages (Non cross)
            elif cat == 'P':
                if self.start_time is not None:
                    res = self.parser.parse_add_order(buffer)
                    self.process_trade_messages(res[0], res[4], res[5], res[3])

            # order executed
            elif cat == 'E':
                if self.order_book:
                    res = self.parser.parse_order_executed(buffer)
                    self.execute_order(res[1], res[2], None, res[0])
            # order executed with price
            elif cat == 'C':
                if self.order_book:
                    res = self.parser.parse_order_executed_with_price(buffer)
                    if res[-1] == 'Y':
                        self.execute_order(res[1], res[2], res[3], res[0])
            # order cancel
            elif cat == 'X':
                if self.order_book:
                    res = self.parser.parse_order_cancel(buffer)
                    self.cancel_order(res[1], res[2])
            # order delete
            elif cat == 'D':
                if self.order_book:
                    res = self.parser.parse_order_delete(buffer)
                    self.delete_order(res[1])
            # order replace
            elif cat == 'U':
                if self.order_book:
                    res = self.parser.parse_order_replace(buffer)

                    self.replace_order(res[1], res[2], res[3], res[4])

    def generate_message_bytes(self, filepath):
        with open(filepath, 'rb') as file:
            with mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as memmap_file:
                while True:
                    message_len = int.from_bytes(memmap_file.read(2), byteorder='big', signed=False)
                    content = memmap_file.read(message_len)
                    yield content

    def save_and_process_add_order(self, order_ref, stock_name, price, volume):
        self.order_book[order_ref] = Order(stock_name, price, volume)

    def execute_order(self, order_ref, exec_shares, exec_price, ts):
        self.add_hourly_stock_data(ts, False)

        if order_ref in self.order_book:
            order = self.order_book.get(order_ref)
            order.volume = max(0, order.volume - exec_shares)
            price = order.price if exec_price is None else exec_price

            # only execution of order will add to cumulative volume/vol*price
            if order.stock in self.stock_data:
                self.stock_data[order.stock]['cumu_vol'] += exec_shares
                self.stock_data[order.stock]['cumu_volpri'] += exec_shares * price
            else:
                self.stock_data[order.stock] = {'cumu_vol': exec_shares, 'cumu_volpri': exec_shares * price, 'hourly_data': {}}
            if order.volume == 0:
                self.order_book.pop(order_ref)

    def cancel_order(self, order_ref, cancelled_shares):
        if order_ref in self.order_book:
            order = self.order_book.get(order_ref)
            order.volume = max(0, order.volume - cancelled_shares)
            if order.volume == 0:
                self.order_book.pop(order_ref)
            else:
                self.order_book[order_ref] = order

    def delete_order(self, order_ref):
        if order_ref in self.order_book:
            self.order_book.pop(order_ref)

    def replace_order(self, orig_order_ref, new_order_ref, shares, price):
        if orig_order_ref in self.order_book:

            order = self.order_book[orig_order_ref]
            order.volume = shares
            order.price = price

            self.order_book.pop(orig_order_ref)
            self.order_book[new_order_ref] = order

    def process_trade_messages(self, ts, stock, price, volume):
        self.add_hourly_stock_data(ts, False)

        if stock in self.stock_data:
            self.stock_data[stock]['cumu_vol'] += volume
            self.stock_data[stock]['cumu_volpri'] += volume * price
        else:
            self.stock_data[stock] = {'cumu_vol': volume, 'cumu_volpri': volume * price,
                                            'hourly_data': {}}



    def add_hourly_stock_data(self, ts, isMarketClose):

        if self.checkpoint is None:
            self.checkpoint = self.start_time + 60 * 60
        if isMarketClose or ts // 1000000000 > self.checkpoint:
            if isMarketClose:
                self.checkpoint = ts // 1000000000
            print('adding hourly data for', ts, '\ncheckpoint ', self.get_time(self.checkpoint * 1e9))
            for stock_name in self.stock_data:
                # volume-weighted average price (VWAP) = cumulative(price*volume)/cumulative(volume)
                self.stock_data[stock_name]['hourly_data'][self.get_time(self.checkpoint * 1e9)] \
                    = self.stock_data[stock_name]['cumu_volpri'] / self.stock_data[stock_name]['cumu_vol']
            self.checkpoint += 60 * 60
            # print("Total time ", pd.to_timedelta(time.time_ns() - start))  # 12 min(norm-bin)

    def get_time(self, ns):
        seconds = ns // 1000000000
        minutes, seconds = seconds // 60, seconds % 60
        hrs, minutes = minutes // 60, minutes % 60
        return '{}:{}:{}'.format(hrs, minutes, seconds)